/* 1.2.1 2021-04-23 18:14:05 */
window._electron=require("electron").remote,window._electron.os=require("os"),window._electron.machine=require("node-machine-id");