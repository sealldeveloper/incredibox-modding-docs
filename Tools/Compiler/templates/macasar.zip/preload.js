/* 1.1.5 2020-11-19 18:12:34 */
window._electron=require("electron").remote,window._electron.machine=require("node-machine-id"),window._electron.os=require("os");